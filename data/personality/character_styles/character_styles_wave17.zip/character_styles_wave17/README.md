# Character Styles — Wave 17 (Still-Missing Titles Only)

Anime: Clannad (Tomoya, Nagisa), Hajime no Ippo, Ping Pong (Smile, Peco), Odd Taxi, Mushishi, Psycho-Pass, Banana Fish (Ash, Eiji), Heavenly Delusion (Kiruko, Maru)
Movies: Grave of the Fireflies, Perfect Blue, Suzume (Souta, Suzume), Ghost in the Shell
K-Drama: Signal, Beyond Evil, Misaeng, Prison Playbook, Mr. Queen
Cartoons: Owl House (Luz, Eda), Samurai Jack, Castlevania (Trevor), Over the Garden Wall (Wirt, Greg)
Manhwa/LN: Doom Breaker, Eternally Regressing Knight, Hyouka (Oreki, Chitanda), Bunny Girl Senpai (Sakuta, Mai)
