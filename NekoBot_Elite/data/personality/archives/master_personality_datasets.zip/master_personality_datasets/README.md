# Master Personality Datasets Archive

This archive contains **all** personality datasets from the original collection. Nothing has been omitted.

## Contents

### Core Packages
- **all_personality_datasets.zip** – Master package with nanora_dataset.jsonl, personality_pack/, and extensive neko/ skins (~100+ personalities)
- **personality_pack_full.zip** – Full personality pack with 22+ core definitions, sample JSONL datasets, question bank, generator, and nanora variants
- **neko-bot-merged.zip** – Complete Neko bot source code including personality system, skins, jokes, memory, triggers
- **nanora_dataset.jsonl** – Standalone Nanora conversation dataset (1093+ Q&A pairs)

### Expansions
- **missing_personalities_expansion.zip**
- **missing_personalities_expansion_2.zip**

### Character Styles (Waves 1–12)
- character_styles_wave1.zip through character_styles_wave12.zip
  - Anime, game, and comic character personality styles (Ainz, Aizen, Elric brothers, Anya, Batman, Denji, Eren, Frieren, Goku, Guts, Hisoka, Homelander, Itachi, Johan, Joker, Killua, L, and many more)

## Recommended usage
1. Start with `personality_pack_full.zip` or `all_personality_datasets.zip` for the core system.
2. Use the character_styles waves for specific character imitations.
3. `nanora_dataset.jsonl` is ready for fine-tuning or evaluation.

Generated: 2026-09-27
