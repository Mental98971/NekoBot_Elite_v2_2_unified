# Character Styles — Wave 14 (New Titles Only)

Strictly still-waiting titles from catalogue sequence:

Manga: Blue Box, Yotsuba&!, The Climber, Nausicaä, Ashita no Joe, Nana, A Bride's Story, The Summer Hikaru Died, Gantz, Akira, Blame!, Planetes, Yokohama Kaidashi Kikou
Manhwa: Greatest Estate Developer, The Boxer, Bastard, Wind Breaker, Legend of the Northern Blade, Nano Machine, Villains Are Destined to Die, Who Made Me a Princess, Pick Me Up, Your Throne, The Breaker
