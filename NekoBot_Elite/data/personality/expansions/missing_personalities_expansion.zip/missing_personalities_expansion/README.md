# Missing Personalities Expansion Pack

**71 high-quality personality definitions** intelligently generated to fill the major gaps identified across the full Nanora / Neko / Personality Pack corpus.

## What was missing and is now added

### Mythical / Supernatural
- Vampire, Vampire Lord, Werewolf, Demon, Angel
- Ghost, Fairy, Dragon, Kitsune
- Fire Elemental, Water Elemental

### Fantasy / RPG Classes
- Wizard, Warlock, Sorcerer, Druid, Barbarian
- Ranger, Monk, Necromancer, Artificer

### Anime / Dere & Tropes
- Undere, Sadodere, Yangire, Kamidere
- Bokukko, Ojousama, Genki, Tomboy, Femboy
- Delinquent, Childhood Friend, Senpai
- Deeper Kuudere variant

### Real-World Professions & Roles
- Detective, Doctor, Soldier, Spy, Assassin
- Therapist, Lawyer, Journalist, Streamer
- Artist, Musician, Athlete, Priest, Maid, Bartender

### Heroic / Social Archetypes
- Hero, Antihero, Mentor, Rival

### Iconic / Literary Styles
- Sherlock, Batman, Joker, Yoda
- Deadpan Genius, Byronic
- Stoic Philosopher, Cynic, Nihilist

### Royalty
- King, Queen

### Sci-Fi / Meta
- Android, AI Entity, Time Traveler, Isekai Protagonist
- Mad Scientist, Cult Leader

## Format

Every file follows the same schema as the original `personality_pack/personalities/*.json`:

- `id`, `name`, `description`, `keywords`
- `sarcasm_level`, `metaphor_frequency`, `exaggeration_level`
- `deadpan`, `deadpan_safe`
- `programmer_humor`, `anime_references`, `max_response_length`
- `persona_context` (system-prompt style)
- `themed_openers`, `themed_closers`, `themed_prefixes`
- `emoji_pool`, `metaphor_pools`
- `response_style_notes`, `example_responses`

## Integration

1. Copy any or all `*.json` files into your bot’s personality presets / skins directory.
2. They are compatible with the existing `CustomInstructionProcessor` / SkinLoader pipeline.
3. Use alongside the original 24 from `personality_pack` and the large Neko skin set.

## Notes

- These were generated to be **production-usable**, not mere stubs.
- Tone, metaphor density, and example quality match the existing high-quality entries (Nanora, Tsundere, Pirate, etc.).
- Some extremely niche or sensitive items (certain clinical labels, political extremes, etc.) were intentionally deprioritized in favor of high-demand, widely recognized archetypes.

Total new personalities in this expansion: **71**
