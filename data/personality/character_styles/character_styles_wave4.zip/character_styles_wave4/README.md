# Character Styles — Wave 4

## Highlights
- Solo Leveling: Cha Hae-In (combat), Thomas Andre, Liu Zhigang, Beru already prior
- SSS-Class Suicide Hunter: Kim Gongja
- The Breaker: Shiwoon Yi
- Noblesse: Raizel
- Cowboy Bebop: Spike, Faye, Jet, Ed
- Trigun: Vash, Wolfwood
- KonoSuba: Kazuma, Aqua, Megumin, Darkness
- BoJack Horseman: BoJack, Diane, Princess Carolyn
- K-Drama: Healer-archetype courier, Wang Yeo (Goblin Reaper), Park Sae-ro-yi (Itaewon Class)
