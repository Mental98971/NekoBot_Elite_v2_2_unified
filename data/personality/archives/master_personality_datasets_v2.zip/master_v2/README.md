# Master Personality Datasets Archive v2
**Generated:** 2026-09-28  
**Total packages:** Complete collection – nothing omitted

## Directory Structure

```
master_v2/
├── core/                          # Primary personality systems & datasets
│   ├── all_personality_datasets.zip
│   ├── personality_pack_full.zip
│   └── nanora_dataset.jsonl
├── expansions/                    # Additional personality definitions
│   ├── missing_personalities_expansion.zip
│   └── missing_personalities_expansion_2.zip
├── character_styles/              # Character imitation packs (Waves 1–27)
│   └── character_styles_wave{1..27}.zip
├── neko/                          # Full Neko bot + personality engine
│   └── neko-bot-merged.zip
└── README.md
```

## Contents Overview

### core/
| File | Description |
|------|-------------|
| `all_personality_datasets.zip` | Master package containing nanora_dataset.jsonl, full personality_pack (definitions + samples + generator + question bank), and extensive neko/ skins collection (~100+ JSON personality skins) |
| `personality_pack_full.zip` | Standalone personality pack: 22+ core personality JSONs, sample JSONL datasets (chaotic_300, cute_250, nanora_400, tsundere_250, etc.), nanora original/modified banks, generator.py, schema.json, README |
| `nanora_dataset.jsonl` | Standalone Nanora conversation dataset (1093+ Q&A pairs with categories, timestamps, responses) |

### expansions/
| File | Description |
|------|-------------|
| `missing_personalities_expansion.zip` | First expansion of additional personality definitions |
| `missing_personalities_expansion_2.zip` | Second, larger expansion of personality definitions |

### character_styles/ (Waves 1–27)
27 independent packs of character-style personality definitions.  
Includes anime, manga, game, and comic characters (examples from early waves: Ainz Ooal Gown, Aizen Sousuke, Alphonse/Edward Elric, Anya Forger, Batman, Denji, Eren Yeager, Frieren, Goku, Guts, Hisoka, Homelander, Itachi, Johan Liebert, Joker, Killua, L Lawliet, and many more across later waves).

### neko/
| File | Description |
|------|-------------|
| `neko-bot-merged.zip` | Complete Neko bot source tree including personality system, skins, jokes, memory, triggers, custom instructions, subplugins, economy, audio engine, etc. |

## Engineering Notes

- **No data dropped**: Every original archive from the collection is present.
- **Intelligent organization**: Grouped by purpose (core system, expansions, character styles, bot implementation) to avoid a flat dump of 30+ zips.
- **Nested zips preserved**: Original packaging is kept intact so consumers can extract only what they need.
- **Size**: ~3–4 MB compressed (exact size after final zip).
- **Recommended entry points**:
  1. Start with `core/personality_pack_full.zip` or `core/all_personality_datasets.zip` for the personality system.
  2. Use `character_styles/` for specific character role-play / imitation.
  3. Use `neko/neko-bot-merged.zip` if integrating into the Neko bot.
  4. `core/nanora_dataset.jsonl` is ready for fine-tuning or evaluation.

## File Counts
- Core packages: 3
- Expansion packages: 2
- Character style waves: 27
- Neko bot: 1
- **Total source archives: 33** + this README
