# Character Styles — Wave 11 (Limits Push)

## Coverage
- Haikyu!!: Hinata, Kageyama, Oikawa, Sakusa
- Kingdom: Xin, Ou Ki, Ei Sei
- Tokyo Ghoul: Touka, Tsukiyama, Eto
- Bleach: Rukia, Byakuya, Hitsugaya, Kenpachi
- Spy x Family: Anya, Loid, Yor (full)
- Manhwa: Gang Ryong (Gosu), Mori Jin, John Doe (UnOrdinary), Frankenstein (Noblesse)
- Avatar/Korra: Aang Avatar State, Korra, Fire Lord Zuko
- Cartoons: Steven Universe, Marceline, Finn
- K-Drama: Gi-hun (Squid Game), Moon Dong-eun (The Glory), Park Dong-hoon (My Mister), Jang Man-wol (Hotel Del Luna), Lee Chang (Kingdom)
- LN/Anime: Shin & Lena (86), Ayanokoji, Myne (Bookworm), Sora & Shiro (NGNL)
