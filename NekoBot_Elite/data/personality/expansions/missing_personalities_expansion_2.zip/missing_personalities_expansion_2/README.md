# Missing Personalities Expansion Pack — Part 2

**213 additional high-quality personality definitions** covering the remaining major categories from the exhaustive gap analysis.

## Categories included

- **MBTI** — all 16 types (INTJ through ESFP)
- **Enneagram** — all 9 types
- **Zodiac** — all 12 signs
- **Elementals** — Earth, Air, Lightning, Ice, Shadow, Light, Void, Nature (Fire/Water already in Pack 1)
- **Animal archetypes** — Wolf, Fox, Cat, Dog, Raven, Owl, Eagle, Snake, Bear, Lion, Tiger, Rabbit, Deer + Foxgirl, Wolfgirl, Bunny, Puppy, Kitten
- **Villain subtypes** — Overlord, Dark Lord, Tyrant, Manipulator, Traitor, Betrayer, Saboteur, Serial Killer, Chaos Agent, Corrupt Politician
- **Superhero / Comic roles** — Speedster, Tank, Glass Cannon, Blaster, Bruiser, Infiltrator, Vigilante, Masked Hero, Anti-Villain
- **Video game archetypes** — DPS, Healer, Carry, Jungler, Midlaner, ADC, Tryhard, Speedrunner, Completionist, Lore Hunter, Min-Maxer, Grinder
- **Historical / Cultural eras** — Ancient Greek, Roman, Egyptian, Victorian, Edwardian, Renaissance, Enlightenment, Viking Age, Feudal Japan, Edo, Celtic, Norse
- **Religious / Spiritual** — Nun, Imam, Rabbi, Pastor, Bishop, Pope, Saint, Prophet, Mystic, Seer, Medium, Atheist, Agnostic, Pagan, Satanist, Cultist
- **Political / Ideological** — Anarchist, Communist, Socialist, Capitalist, Libertarian, Conservative, Liberal, Progressive, Reactionary, Monarchist, Nationalist, Globalist, Pacifist, Militarist, Environmentalist, Technocrat
- **Academic disciplines** — Mathematician, Physicist, Chemist, Biologist, Historian, Linguist, Sociologist, Anthropologist, Economist, Neuroscientist, Computer Scientist, Theologian, Logician
- **Musical & artistic movements** — Classical, Jazz, Blues, Rock, Metal, Punk, Hip-Hop, Electronic, Ambient, Folk, Country, Impressionist, Expressionist, Surrealist, Dadaist, Abstract, Pop Art
- **Sports roles** — Quarterback, Striker, Goalkeeper, Point Guard, Pitcher, Swimmer, Runner, Cyclist, Gymnast, Wrestler, MMA Fighter, Fencer, Archer
- **Age / life stages** — Toddler, Child, Preteen, Teenager, Young Adult, Middle-Aged, Elderly, Ancient, Immortal
- **Sci-fi / meta tropes** — Dimension Hopper, Reincarnator, Overpowered, Cursed, Blessed, Chosen One, Reluctant Hero, Fallen Hero, Amnesiac, Clone, Cyborg, Hologram, Puppet, Doll, Mannequin
- **Extra anime** — Hinedere, Nyandere, Bishounen, Bishoujo, Class Rep, Transfer Student, Mangaka, Voice Actor

All files use the same schema as the original personality_pack and Expansion 1.
