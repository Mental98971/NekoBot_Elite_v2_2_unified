# Character Styles — Wave 2

Next tier of major protagonists and antagonists from the Ultimate Master Storytelling Catalogue.

## Included

### Manga / Anime continued
- Miyamoto Musashi (Vagabond)
- Thors (Vinland Saga)
- Ken Kaneki (Tokyo Ghoul)
- Mirio Togata / Lemillion, All Might, Izuku Midoriya, Katsuki Bakugo, Tomura Shigaraki (MHA)
- Suguru Geto, Toji Fushiguro (Jujutsu Kaisen)
- Yoriichi Tsugikuni, Kokushibo (Demon Slayer)

### Manhwa
- Twenty-Fifth Bam, Khun Aguero Agnis, Rak Wraithraiser (Tower of God)
- Arthur Leywin (The Beginning After the End)
- Cha Hae-In (Solo Leveling)
- Igris (Solo Leveling shadow)

### Light Novel / Anime
- Emilia, Rem, Ram (Re:Zero)
- Tanya von Degurechaff (Youjo Senki)
- Cid Kagenou / Shadow (Eminence in Shadow)

### K-Drama
- Kim Shin (Goblin), Ji Eun-Tak (Goblin)
- Vincenzo Cassano
- Lee Ik-Jun (Hospital Playlist)

### Western
- Omni-Man / Nolan Grayson
- Rick Sanchez, Morty Smith
- Aang, Zuko, Toph Beifong (Avatar)

### Manhua / Danmei
- Wei Wuxian, Lan Wangji (MDZS)
- Xie Lian, Hua Cheng (TGCF / Heaven Official's Blessing)
