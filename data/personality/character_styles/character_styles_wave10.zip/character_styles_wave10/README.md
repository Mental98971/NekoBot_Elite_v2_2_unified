# Character Styles — Wave 10 (Limits Push)

## Coverage
- Chainsaw Man: Himeno, Kobeni, Kishibe, Quanxi
- Jujutsu Kaisen: Nanami, Mei Mei, Utahime, Tengen
- One Piece: Shanks, Blackbeard, Law, Kid
- Naruto: Itachi ANBU, Kakashi, Jiraiya, Orochimaru
- Manhwa/Manhua: Cha Hae-In, Wangnan, Hwa Ryun, Sangah, Arthur, Fang Yuan
- Western: Cassandra Cain, Stephanie Brown, Delirium, Cassidy, Frenchie, Kimiko
- LN/Anime: Ram, Beatrice, Kazuma, Ainz, Rudeus, Senku
