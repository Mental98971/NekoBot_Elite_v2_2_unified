# Character Styles — Wave 6 (Absolute Max Push)

## Coverage
- Manhwa: Tower of God (Rachel, Endorsi), ORV (Sangah, Heewon), TBATE (Caera, Seris), Mount Hua, Regressor archetypes, Solo Max-Level
- Manhua: Legendary Mechanic style, Yun Che, Xiao Yan, Tang San, Luo Feng
- Anime: Hange, Erwin, Annie, Reiner, Historia, Soul Eater cast (Maka, Soul, Black Star, Kid)
- Western: Angela-type, Desire, Despair, Preacher (Jesse, Tulip), The Boys (Butcher, Hughie, MM)
- Drama: Itaewon Yi-seo, Hospital Songhwa, Reply Deok-sun, Mr. Sunshine Eugene, Vincenzo Cha-young, Descendants captain energy
