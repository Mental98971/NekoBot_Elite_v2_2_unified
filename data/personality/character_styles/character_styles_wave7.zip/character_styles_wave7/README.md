# Character Styles — Wave 7

## Coverage
- Hunter x Hunter: Illumi, Chrollo, Kurapika, Netero, Meruem, Adult Gon, Leorio
- Dr. Stone: Senku, Chrome, Kohaku, Tsukasa, Gen
- Lookism: Zack, Vasco; Wind Breaker Jay; Eleceed Jiwoo; World After the Fall
- Oregairu: Yui, Hiratsuka; Spice and Wolf: Holo, Lawrence
- Re:Zero knight Subaru; Overlord: Shalltear, Cocytus
- Invincible: Atom Eve, Robot; The Boys: Starlight; Sandman: Hob; Saga: Alana, Marko
- C-Drama: Yanxi Yingluo, Dongfang Qingcang, Hidden Love Sang Zhi
