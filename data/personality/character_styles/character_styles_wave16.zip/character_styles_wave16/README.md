# Character Styles — Wave 16 (Still-Missing Titles Only)

Anime: Violet Evergarden, Gurren Lagann, Made in Abyss, Oshi no Ko, Samurai Champloo, Bocchi the Rock, Cyberpunk Edgerunners, Ranking of Kings
Movies: Your Name, A Silent Voice, Princess Mononoke
K-Drama: Flower of Evil, Moving, Weak Hero, D.P.
LN: Monogatari, DanMachi, Goblin Slayer, Fate/stay night
Web Novels: Overgeared, S-Classes That I Raised, Lord of the Mysteries
