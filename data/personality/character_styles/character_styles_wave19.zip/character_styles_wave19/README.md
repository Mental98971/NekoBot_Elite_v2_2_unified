# Character Styles — Wave 19 (Still-Missing Titles Only)

Western Comics: Walking Dead (Rick), Y: The Last Man, Locke & Key, Preacher, Chew, Monstress, All-Star Superman, Fables
Anime/LN: Mayuri (Steins;Gate), Accelerator, Misaka, Kanbaru, Shinobu, Hachiman, Yukino
K-Drama: Crash Landing on You, Itaewon Class, Vincenzo
Cartoons: Regular Show, Harley Quinn TV, Bluey
Manhwa: Unholy Blood, Her Summon, Purple Hyacinth, See You in My 19th Life
