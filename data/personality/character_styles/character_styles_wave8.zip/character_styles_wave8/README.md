# Character Styles — Wave 8 (Limits Push)

## Coverage
- Death Note: Misa, Ryuk, Near, Mello
- One Piece extended: Ace, Sabo, Nami, Robin, Chopper, Franky, Brook, Jinbe
- Solo Leveling Esil; TBATE Regis; ORV Hyunsung; Trash of the Count's Family Cale
- Mob Psycho: Ritsu, Teru; One-Punch Man: Sonic, Fubuki, Tatsumaki
- Batman family: Nightwing, Red Hood, Oracle
- Sandman Destruction; Lucifer Mazikeen
- Drama: Samshin, Se-ri, Jang Dae-hee, Choi Taek, Go Ae-sin
- Frieren party: Himmel, Eisen, Heiter
- Delicious in Dungeon: Laios, Senshi
- Apothecary Diaries: Maomao, Jinshi
