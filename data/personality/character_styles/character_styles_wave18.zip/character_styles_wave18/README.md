# Character Styles — Wave 18 (Still-Missing Titles Only)

C/J-Drama: Love Between Fairy and Devil, Joy of Life, The Long Season, Midnight Diner
Anime: Serial Experiments Lain, Ergo Proxy, LOGH (Yang, Reinhard), Wolf Children, Girl Who Leapt Through Time
Cartoons: Powerpuff (Blossom), She-Ra (Adora, Catra), Primal (Spear, Fang)
Manhwa/Manhua: Latna Saga, Apotheosis, Legendary Mechanic, A Will Eternal
K-Drama: Sky Castle, My Liberation Notes, Hospital Playlist (Jeong-won), Business Proposal
Web Novels: Ranker Who Lives a Second Time, Novel's Extra, Great Mage Returns
