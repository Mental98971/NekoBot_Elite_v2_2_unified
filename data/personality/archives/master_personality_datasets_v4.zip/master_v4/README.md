# Master Personality Datasets Archive v4

**Generated:** 2026-09-28  
**Policy:** Nothing skipped or dropped. All source archives from v3 retained. VTuber expansion added.

## Directory Structure

```
master_v4/
├── core/                          # Primary personality systems & datasets
│   ├── all_personality_datasets.zip
│   ├── personality_pack_full.zip
│   └── nanora_dataset.jsonl
├── expansions/                    # Additional personality definitions
│   ├── missing_personalities_expansion.zip
│   └── missing_personalities_expansion_2.zip
├── character_styles/              # Character imitation packs (Waves 1–39)
│   └── character_styles_wave{1..39}.zip
├── neko/                          # Neko bot implementations
│   ├── neko-bot-merged.zip
│   └── NekoBot_Production.zip
└── README.md
```

## What Changed in v4

- **Added** `character_styles/character_styles_wave39.zip` — 30 famous VTuber personality styles
- **Nothing removed or altered** from v3 core, expansions, waves 1–38, or neko packages
- README updated to reflect Wave 39 and VTuber coverage

## Wave 39 — VTuber Personalities (30)

| # | ID | Name |
|---|-----|------|
| 1 | kizuna_ai | Kizuna AI |
| 2 | gawr_gura | Gawr Gura |
| 3 | houshou_marine | Houshou Marine |
| 4 | usada_pekora | Usada Pekora |
| 5 | hoshimachi_suisei | Hoshimachi Suisei |
| 6 | shirakami_fubuki | Shirakami Fubuki |
| 7 | sakura_miko | Sakura Miko |
| 8 | kuzuha | Kuzuha |
| 9 | inugami_korone | Inugami Korone |
| 10 | mori_calliope | Mori Calliope |
| 11 | ironmouse | Ironmouse |
| 12 | kobo_kanaeru | Kobo Kanaeru |
| 13 | nekomata_okayu | Nekomata Okayu |
| 14 | minato_aqua | Minato Aqua |
| 15 | oozora_subaru | Oozora Subaru |
| 16 | tokino_sora | Tokino Sora |
| 17 | shigure_ui | Shigure Ui |
| 18 | filian | Filian |
| 19 | ninomae_inanis | Ninomae Ina'nis |
| 20 | watson_amelia | Watson Amelia |
| 21 | kanae | Kanae |
| 22 | koseki_bijou | Koseki Bijou |
| 23 | pmaru_sama | Pmaru-sama |
| 24 | shylily | Shylily |
| 25 | neuro_sama | Neuro-sama |
| 26 | zentreya | Zentreya |
| 27 | ookami_mio | Ookami Mio |
| 28 | tsunomaki_watame | Tsunomaki Watame |
| 29 | kaguya_luna | Kaguya Luna |
| 30 | woowakgood | Woowakgood |

Schema matches Waves 1–38 character_styles (id, name, description, keywords, sarcasm/metaphor/exaggeration levels, deadpan, persona_context, openers, closers, emoji_pool, example_responses).

## Contents Overview (unchanged from v3 + Wave 39)

### core/
| File | Description |
|------|-------------|
| `all_personality_datasets.zip` | Master package: nanora_dataset.jsonl + full personality_pack + extensive neko skins |
| `personality_pack_full.zip` | Standalone pack: core personality JSONs, sample JSONL datasets, generator, schema |
| `nanora_dataset.jsonl` | Standalone Nanora conversation dataset |

### expansions/
| File | Description |
|------|-------------|
| `missing_personalities_expansion.zip` | First expansion of additional personality definitions |
| `missing_personalities_expansion_2.zip` | Second, larger expansion |

### character_styles/ (Waves 1–39)
39 independent packs of character-style personality definitions covering anime, manga, games, comics, and now VTubers.

### neko/
| File | Description |
|------|-------------|
| `neko-bot-merged.zip` | Full Neko bot source tree |
| `NekoBot_Production.zip` | Production-oriented Neko bot package |

## Engineering Notes

- **Completeness**: Every archive from v3 is retained. Wave 39 is additive only.
- **No mutations**: core/, expansions/, waves 1–38, and neko/ are byte-identical to v3 sources.
- **Schema continuity**: VTuber JSONs use the same character_styles schema as prior waves for drop-in loader compatibility.
- **Recommended entry points**:
  1. `core/personality_pack_full.zip` or `core/all_personality_datasets.zip` for the personality system
  2. `character_styles/` for character / VTuber role-play packs
  3. `neko/` for bot integration
  4. `core/nanora_dataset.jsonl` for fine-tuning or evaluation

## File Counts
- Core packages: 3
- Expansion packages: 2
- Character style waves: **39** (was 38)
- Neko packages: 2
- **Total source archives: 46** + this README
