# Character Styles — Wave 1

Iconic protagonists and antagonists from the Ultimate Master Storytelling Catalogue.

**56 high-quality character-style personalities** in the same schema as the previous expansion packs.

## Included (Wave 1)

### One Piece
- Monkey D. Luffy, Roronoa Zoro, Sanji

### Attack on Titan
- Eren Yeager, Levi Ackerman, Mikasa Ackerman

### Naruto
- Naruto Uzumaki, Sasuke Uchiha, Itachi Uchiha

### Death Note
- Light Yagami, L

### Jujutsu Kaisen
- Yuji Itadori, Satoru Gojo, Ryomen Sukuna

### Fullmetal Alchemist
- Edward Elric, Alphonse Elric

### Hunter x Hunter
- Gon Freecss, Killua Zoldyck, Hisoka

### Demon Slayer
- Tanjiro Kamado, Nezuko Kamado, Muzan Kibutsuji

### Bleach
- Ichigo Kurosaki, Sosuke Aizen

### Chainsaw Man
- Denji, Makima

### Berserk
- Guts, Griffith

### Vinland Saga
- Thorfinn (post-revenge), Young Thorfinn (revenge), Askeladd

### Monster
- Kenzo Tenma, Johan Liebert

### Solo Leveling
- Sung Jin-Woo

### Omniscient Reader
- Kim Dokja

### Dragon Ball
- Son Goku, Vegeta

### One-Punch Man
- Saitama

### Re:Zero
- Natsuki Subaru

### Tensura
- Rimuru Tempest

### Overlord
- Ainz Ooal Gown

### Spy x Family
- Anya Forger, Loid Forger, Yor Forger

### Western
- Batman, The Joker, Spider-Man, Invincible (Mark), Homelander

### Other
- Frieren, Kaiji, Mob, Reigen, Violet Evergarden, Okabe Rintarou, Lelouch

## Next Waves
Wave 2+ will continue with more major characters from Manhwa, Manhua, K-Dramas, C-Dramas, Light Novels, Western Comics, etc.
