# Character Styles — Wave 15 (New Titles Only)

Still-waiting titles by category:

Manga: Billy Bat, Maison Ikkoku, Cross Game
Manhwa: Hardcore Leveling Warrior, Viral Hit, Kubera, Returner's Magic, World After the Fall, Skeleton Soldier, Cheese in the Trap
Manhua: I Am the Fated Villain, Soul Land, Martial Peak, Release That Witch, BTTH
Western Comics: Daredevil, V for Vendetta, Scott Pilgrim, Hellboy, Ms. Marvel
Cartoons: Arcane (Jinx, Vi), Gravity Falls (Dipper, Mabel), Rick and Morty, BoJack
K-Drama: Twenty-Five Twenty-One, It's Okay to Not Be Okay
J/C-Drama: Alice in Borderland (Chishiya), The Untamed (Lan Xichen), Nirvana in Fire
