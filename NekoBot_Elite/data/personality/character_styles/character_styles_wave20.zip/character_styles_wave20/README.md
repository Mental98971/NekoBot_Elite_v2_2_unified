# Character Styles — Wave 20 (Still-Missing Titles Only)

Anime: JoJo (Joseph, Jotaro, Giorno), Kingdom (Shin, Ei Sei), Demon Slayer (Inosuke, Zenitsu, Sanemi), Howl (Calcifer, Sophie), Cat Returns (Baron)
K-Drama: Goblin, Descendants of the Sun, Reply 1988
Manhwa: Tower of God (Bam, Khun, Rak), Solo Leveling (Cha Hae-In), ORV (Kim Dokja, Yoo Joonghyuk)
Web Novels: Mother of Learning, Wandering Inn, Practical Guide to Evil, He Who Fights With Monsters
C-Drama: Word of Honor (Wen Kexing, Zhou Zishu)
Vinland: Canute
