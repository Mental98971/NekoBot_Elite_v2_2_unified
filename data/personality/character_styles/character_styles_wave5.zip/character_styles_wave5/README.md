# Character Styles — Wave 5 (Maximum Push)

Large batch covering remaining high-value protagonists/antagonists across Manhwa, Manhua, Anime, Western, Drama, and Light Novels.

## Categories covered
- Solo Leveling extended cast
- Hardcore Leveling Warrior, Wind Breaker, Viral Hit, Mercenary Enrollment
- Who Made Me a Princess, Your Throne, TBATE (Sylvie)
- Manhua cultivation: Lin Fan, Han Li, Meng Hao, Wang Lin, Bai Xiaochun, Fang Yuan, Klein Moretti
- Code Geass (C.C., Suzaku), Steins;Gate (Kurisu, Mayuri)
- Madoka Magica (Homura, Madoka)
- One-Punch Man (Mumen Rider, King)
- Superman, Wonder Woman, Harley Quinn, Constantine, Swamp Thing, Lucifer
- K-Drama: Crash Landing, Goblin Sunny, Alchemy of Souls, Twenty-Five Twenty-One
- Tensura/Overlord/Re:Zero/Mushoku extended
- Vinland (Einar, Canute), Chainsaw Man (Power, Aki, Quanxi)
