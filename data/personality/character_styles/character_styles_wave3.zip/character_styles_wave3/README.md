# Character Styles — Wave 3

Continuing major protagonists and antagonists from the Ultimate Master Storytelling Catalogue.

## Included (selection)

### Manhwa
- Lloyd Frontera (Greatest Estate Developer)
- Kayden Break, Seo Jiwoo (Eleceed)
- Yoo Joonghyuk, Han Sooyoung (Omniscient Reader)
- Yu (The Boxer)
- Daniel Park (Lookism)
- Cha Hyun-soo (Sweet Home)
- Beru (Solo Leveling)

### Manga / Anime
- Gintoki, Kagura, Hijikata (Gintama)
- Genos, Dimple (One-Punch Man / Mob Psycho)
- Hachiman, Yukino (Oregairu)
- Akira Tendo (Zom 100)
- Shoko Ieiri, Kento Nanami (Jujutsu Kaisen)
- Jiang Cheng, Lan Xichen (MDZS)

### Western
- Dream / Morpheus, Death (Sandman)
- Spawn, Hellboy

### C-Drama
- Mei Changsu (Nirvana in Fire)
