# Character Styles — Wave 13 (New Titles Only)

No re-adds from previously covered series. Sequence-wise new titles from the catalogue:

- Vagabond: Musashi, Takuan
- Grand Blue: Kitahara, Imamura
- Sakamoto Days: Sakamoto, Shin Asakura
- Witch Hat Atelier: Coco, Qifrey
- 20th Century Boys: Kenji
- Kagurabachi: Chihiro Rokuhira
- Horimiya: Hori, Miyamura
- Pluto: Gesicht
- Dorohedoro: Caiman, Nikaido
- Golden Kamuy: Sugimoto, Asirpa
- Ajin: Kei Nagai
- Parasyte: Shinichi, Migi
- Land of the Lustrous: Phos
- Ancient Magus' Bride: Chise, Elias
- Dandadan: Momo, Okarun
- Fruits Basket: Tohru, Kyo
- March Comes in Like a Lion: Rei Kiriyama
- Sweet Home: Cha Hyun-soo
- Lookism: Daniel Park
- Eleceed: Jiwoo, Kayden
