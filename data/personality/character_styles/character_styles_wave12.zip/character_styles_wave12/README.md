# Character Styles — Wave 12 (Major Missing Characters)

## Coverage
- Berserk: Guts, Griffith, Casca
- Monster: Tenma, Johan
- Vinland Saga: Thorfinn, Askeladd, Canute
- Slam Dunk: Sakuragi, Rukawa, Akagi
- Code Geass: Lelouch, C.C.
- Evangelion: Shinji
- Steins;Gate: Okabe
- Gintama: Gintoki, Kagura, Hijikata
- MDZS / TGCF / King's Avatar: Wei Wuxian, Lan Wangji, Xie Lian, Hua Cheng, Ye Xiu
- Invincible: Mark, Omni-Man
- Watchmen: Rorschach, Ozymandias
- Saga: Alana, Marko
- Alice in Borderland: Arisu; Hanzawa Naoki; Shogun Toranaga
- Spirited Away: Chihiro; Howl; Tanya; Holo
