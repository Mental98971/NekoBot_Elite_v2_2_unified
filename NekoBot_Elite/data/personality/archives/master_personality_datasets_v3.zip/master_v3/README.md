# Master Personality Datasets Archive v3
**Generated:** 2026-09-28  
**Policy:** Nothing skipped or dropped. All source archives included.

## Directory Structure

```
master_v3/
├── core/                          # Primary personality systems & datasets
│   ├── all_personality_datasets.zip
│   ├── personality_pack_full.zip
│   └── nanora_dataset.jsonl
├── expansions/                    # Additional personality definitions
│   ├── missing_personalities_expansion.zip
│   └── missing_personalities_expansion_2.zip
├── character_styles/              # Character imitation packs (Waves 1–38)
│   └── character_styles_wave{1..38}.zip
├── neko/                          # Neko bot implementations
│   ├── neko-bot-merged.zip
│   └── NekoBot_Production.zip
└── README.md
```

## Contents Overview

### core/
| File | Description |
|------|-------------|
| `all_personality_datasets.zip` | Master package: nanora_dataset.jsonl + full personality_pack (definitions, samples, generator, question bank) + extensive neko skins (~100+ JSON personalities) |
| `personality_pack_full.zip` | Standalone pack: 22+ core personality JSONs, sample JSONL datasets (chaotic_300, cute_250, nanora_400, tsundere_250, etc.), nanora banks, generator.py, schema, README |
| `nanora_dataset.jsonl` | Standalone Nanora conversation dataset (1093+ Q&A pairs) |

### expansions/
| File | Description |
|------|-------------|
| `missing_personalities_expansion.zip` | First expansion of additional personality definitions |
| `missing_personalities_expansion_2.zip` | Second, larger expansion |

### character_styles/ (Waves 1–38)
38 independent packs of character-style personality definitions covering anime, manga, games, comics and related characters.

### neko/
| File | Description |
|------|-------------|
| `neko-bot-merged.zip` | Full Neko bot source tree (personality system, skins, jokes, memory, triggers, custom instructions, subplugins, etc.) |
| `NekoBot_Production.zip` | Production-oriented Neko bot package |

## Engineering Notes

- **Completeness**: Every individual archive present in the collection is included. Previous master zips were not nested (to avoid recursive bloat); only the source packages are kept.
- **Latest versions preferred**: Where multiple versions of the same file existed historically, the current attachments versions are used.
- **Structure**: Grouped by purpose for easy navigation instead of a flat list of 40+ files.
- **Nested originals preserved**: Consumers can extract only the packages they need without unpacking everything.
- **Recommended entry points**:
  1. `core/personality_pack_full.zip` or `core/all_personality_datasets.zip` for the personality system.
  2. `character_styles/` for character role-play / imitation packs.
  3. `neko/` for bot integration (use Production or Merged according to needs).
  4. `core/nanora_dataset.jsonl` for fine-tuning or evaluation.

## File Counts
- Core packages: 3
- Expansion packages: 2
- Character style waves: 38
- Neko packages: 2
- **Total source archives: 45** + this README
