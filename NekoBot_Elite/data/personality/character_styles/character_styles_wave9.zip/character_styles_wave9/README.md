# Character Styles — Wave 9 (Limits Push)

## Coverage
- Jujutsu Kaisen: Megumi, Nobara, Yuta, Maki, Todo, Mahoraga
- Demon Slayer: Zenitsu, Inosuke, Giyu, Shinobu, Rengoku, Akaza
- Manhwa: Go Gun-Hee combat, Lee Jihye (ORV), Tessia (TBATE)
- Cowboy Bebop Ein; Trigun Knives, Meryl
- Fullmetal: Mustang, Hawkeye, Scar, Ling
- Batman: Tim Drake, Damian; Wonder Woman Steve; Superman Lois; Miles Morales
- Drama: Naksu, Kang Mo-yeon, Babel energy, Jung-hwan, Duan Jiaxu
- HxH: Killua Godspeed, Biscuit; OPM: Bang, Garou; MHA: Todoroki, Uraraka
