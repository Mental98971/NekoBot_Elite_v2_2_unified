# Master Personality Datasets Archive v5

**Generated:** 2026-09-28  
**Policy:** Nothing skipped or dropped. All source archives from v3/v4 retained. Animal + historical/cultural expansions added.

## Directory Structure

```
master_v5/
├── core/                          # Primary personality systems & datasets
│   ├── all_personality_datasets.zip
│   ├── personality_pack_full.zip
│   └── nanora_dataset.jsonl
├── expansions/                    # Additional personality definitions
│   ├── missing_personalities_expansion.zip
│   └── missing_personalities_expansion_2.zip
├── character_styles/              # Character imitation packs (Waves 1–41)
│   └── character_styles_wave{1..41}.zip
├── neko/                          # Neko bot implementations
│   ├── neko-bot-merged.zip
│   └── NekoBot_Production.zip
└── README.md
```

## What Changed in v5

- **Added** `character_styles_wave40.zip` — 35 animal archetypes
- **Added** `character_styles_wave41.zip` — 51 historical / cultural / sports figures
- **Nothing removed or altered** from v4 (core, expansions, waves 1–39, neko)

## Wave 40 — Animal Archetypes (35)

Dog, Cat, Panda, Rabbit, Koala, Dolphin, Penguin, Lion, Elephant, Fox, Tiger, Otter, Horse, Butterfly, Deer, Bear, Parrot, Seal, Giraffe, Whale, Swan, Flamingo, Turtle, Bumblebee, Squirrel, Raccoon, Hedgehog, Frog, Peacock, Dove, Puffin, Firefly, Sloth, Hamster, Alpaca

## Wave 41 — Historical / Cultural / Sports Figures (51)

Jesus Christ, Muhammad, Gautama Buddha, Confucius, Alexander the Great, Julius Caesar, Genghis Khan, Napoleon Bonaparte, Mahatma Gandhi, Albert Einstein, Leonardo da Vinci, William Shakespeare, Isaac Newton, Aristotle, Plato, Socrates, Adolf Hitler (educational/historical framing only), Abraham Lincoln, George Washington, Christopher Columbus, Martin Luther, Karl Marx, Charles Darwin, Galileo Galilei, Nicolaus Copernicus, Thomas Edison, Louis Pasteur, Nikola Tesla, Michael Jackson, Elvis Presley, Marilyn Monroe, Charlie Chaplin, Walt Disney, Steve Jobs, Bill Gates, Cristiano Ronaldo, Lionel Messi, Neymar, Pelé, Muhammad Ali, Michael Jordan, Queen Elizabeth II, Cleopatra, Joan of Arc, Mother Teresa, Nelson Mandela, Martin Luther King Jr., Winston Churchill, Sun Tzu, Marco Polo, Neil Armstrong

**Note on sensitive figures:** Hitler is included strictly as an educational/historical persona for understanding and warning, not glorification. Religious founders are framed respectfully as historical-spiritual teaching voices.

## Schema

Same character_styles schema as Waves 1–39 for drop-in loader compatibility.

## File Counts

- Core packages: 3
- Expansion packages: 2
- Character style waves: **41** (was 39)
- Neko packages: 2
- **Total source archives: 48** + this README
